#include "../../alvr_server/bindings.h"

void HookCrashHandler() { }

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#include <openvr_driver.h>
#pragma GCC diagnostic pop

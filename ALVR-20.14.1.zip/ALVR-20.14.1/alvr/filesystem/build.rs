// This is needed so that `OUT_DIR` is set and `afs::target_dir` works
fn main() {}

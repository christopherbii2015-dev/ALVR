* Hand tracking OSC for VRChat with ALVR support: https://github.com/A3yuu/FingerTruckerOSC
* ALVR in the browser using WebXR and WebCodecs: https://github.com/rinsuki-lab/ALVR/tree/research/alvr-web